package com.example.jaime.tfg.ui.student.record.problemsGroup;

/**
 * Created by Jaime on 21/03/2018.
 */

public interface ProblemsRecordPresenter {
    void getProblemsRecord(String idStudent, String idProblemsGroup, String idRecord, String token);
}
