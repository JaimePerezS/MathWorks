package com.example.jaime.tfg.ui.student.record.operationsGroup;

/**
 * Created by Jaime on 21/03/2018.
 */

public interface OperationsGroupRecordPresenter {
    void getOperationsGroupRecord(String idStudent, String token);
}
