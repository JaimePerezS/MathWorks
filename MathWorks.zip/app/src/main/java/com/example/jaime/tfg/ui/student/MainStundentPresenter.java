package com.example.jaime.tfg.ui.student;

/**
 * Created by Jaime on 18/01/2018.
 */

public interface MainStundentPresenter {
    void getPoints(String idStudent);
    void getAvatar(String idStudent);
}
