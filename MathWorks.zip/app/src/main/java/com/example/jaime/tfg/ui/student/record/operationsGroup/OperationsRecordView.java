package com.example.jaime.tfg.ui.student.record.operationsGroup;

import com.example.jaime.tfg.data.model.OperationsRecord;

import java.util.List;

/**
 * Created by Jaime on 21/03/2018.
 */

public interface OperationsRecordView {
    void showOperationsRecord(List<OperationsRecord> operationsRecordList);
}
