package com.example.jaime.tfg.ui.student.record.problemsGroup;

import com.example.jaime.tfg.data.model.ProblemsRecord;

import java.util.List;

/**
 * Created by Jaime on 21/03/2018.
 */

public interface ProblemsRecordView {
    void showProblemsRecord(List<ProblemsRecord> problemsRecordList);
}
