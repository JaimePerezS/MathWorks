package com.example.jaime.tfg.ui.student.record.problemsGroup;

/**
 * Created by Jaime on 21/03/2018.
 */

public interface ProblemsGroupRecordPresenter {
    void getProblemsGroupRecord(String idStudent, String token);
}
